<?php

return [

    'Hello' => 'Bonjour',

];
