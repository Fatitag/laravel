<?php

return [

    'Hello' => 'Hello',

];
