@extends('layouts.MyLayout')
@section('content')
    <p>Page produits 2</p>
@endsection
@section('nav')
    <p>2</p>
@endsection