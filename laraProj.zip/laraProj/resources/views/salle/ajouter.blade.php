@extends('layouts.testLayout')
@section('content')
    <h1>Page ajout</h1>
@endsection