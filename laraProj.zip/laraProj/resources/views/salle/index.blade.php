@extends('layouts.testLayout')
@section('content')
    <h1>Page index</h1>
@endsection