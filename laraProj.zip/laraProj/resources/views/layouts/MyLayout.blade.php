<html>
    <head>
        <link rel="stylesheet" href="/css/style.css" />
    </head>
    <body>
        <h1>Bonjour!</h1>
        @yield('content')
</body>
</html>