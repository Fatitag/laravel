<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="{{ route('produits.create') }}">Ajouter</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Libellé</th>
            <th>Prix</th>
            <th>Actions</th>
        </tr>
        @foreach ($produits as $produit)
            <tr>
                <td>{{ $produit->id }}</td>
                <td>{{ $produit->libelle }}</td>
                <td>{{ $produit->prix }}</td>
                <th>
                    <a href="{{ route('produits.show', ['produit' => $produit]) }}">Afficher</a>
                    <a href="{{ route('produits.edit', ['produit' => $produit]) }}">Modifier</a>
                    <form action="{{ route('produits.destroy', ['produit' => $produit]) }}" method="post">
                        <input type="submit" value="Supprimer">
                        @csrf
                        @method('DELETE')
                    </form>
                </th>
            </tr>
        @endforeach
    </table>
    {{ $produits->links() }}
</body>
</html>