<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    @foreach ($errors->all() as $error)
        <p>{{ $error }}</p>
    @endforeach
    <form action="{{ route('produits.store') }}" method="post">
        <div>
            <label for="">Libellé</label>
            <input type="text" name="libelle" id="">
        </div>
        <div>
            <label for="">Prix</label>
            <input type="text" name="prix" id="">
        </div>
        <input type="submit" value="Enregistrer">
        @csrf
    </form>
</body>
</html>