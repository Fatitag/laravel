<html>
    <head>
        <style>
            .is-invalid {
                border: 1px red solid;
            }
        </style>
    </head>
    <body>
        <form action="" method="post" enctype="multipart/form-data">
            @if ( $errors->any() )
                <div class="alert alert-danger">
                    <ul>
                        @foreach($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div>
                <label>Nom</label>
                <input type="text" name="nom" value="{{ old('nom') }}" class="@error('nom') is-invalid @enderror" />
            </div>
            <input type="file" name="photo" />
            @csrf
            <input type="submit" value="Envoyer" />
        </form>
    </body>
</html>