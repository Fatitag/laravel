<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="{{ route('employes.create') }}">Ajouter</a>
    <table>
        <tr>
            <th>ID</th>
            <th>First name</th>
            <th>Last name</th>
            <th>Salary</th>
            <th>Actions</th>
        </tr>
        @foreach ($employes as $employe)
            <tr>
                <td>{{ $employe->id }}</td>
                <td>{{ $employe->firstName }}</td>
                <td>{{ $employe->lastName }}</td>
                <td>{{ $employe->salary }}</td>
                <td>
                    <a href="{{ route('employes.show', ['employe' => $employe->id]) }}">Afficher</a>
                    <a href="#">Modifier</a>
                    <form action="{{ route('employes.destroy', ['employe' => $employe->id]) }}" method="post">
                        @csrf
                        @method('DELETE')
                        <input type="submit" value="Supprimer">
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
    {{ $employes->links() }}
</body>
</html>