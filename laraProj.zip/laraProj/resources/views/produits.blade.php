@extends('layouts.MyLayout')
@section('content')
    <p>Page produits</p>
@endsection
@section('nav')
    <form action="" method="post" enctype="multipart/form-data">
        @if ( $errors->any() )
            <div class="alert alert-danger">
                <ul>
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
       
        <div>
            <label>Name</label>
            <input type="text" name="name" value="{{ old('name') }}" />
        </div>
        <div>
            <label>Filière</label>
            <select name="fil">
                <option></option>
                <option value="tdi" @selected(old('fil') == 'tdi')>TDI</option>
                <option value="tri" @selected(old('fil') == 'tri')>TRI</option>
            </select>
        </div>
        <div>
            <label>Sexe</label>
            <input type="radio" name="sexe" value="h" />
            <input type="radio" name="sexe" value="f" />
        </div>
        <div>
            <label>Options</label>
            <input type="checkbox" name="option[]" value="1A" />
            <input type="checkbox" name="option[]" value="2A" />
        </div>
        <div>
            <label>Photo</label>
            <input type="file" name="photo" />
        </div>
        @csrf
        <input type="submit" value="Envoyer" />
    </form>
@endsection