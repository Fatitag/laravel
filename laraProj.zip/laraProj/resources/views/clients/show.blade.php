<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Company Form - Laravel 9 CRUD Tutorial</title>
</head>

<body>
    <div class="container mt-2">
    <a class="btn btn-primary" href="{{ route('clients.index') }}" enctype="multipart/form-data">
                        Back</a>
                        <p>{{ $client->name }}</p>
                        <p>{{ $client->email }}</p>

    @foreach ($client->commandes as $commande)
        <p>{{ $commande->id }}: {{ $commande->dateCom }}</p>
    @endforeach
    </div>
</body>

</html>