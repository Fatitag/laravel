<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Company Form - Laravel 9 CRUD</title>
</head>

<body>
    <ul>
        <li><a href="{{ route('changeLang', ['locale' => 'en']) }}">En</a></li>
        <li><a href="{{ route('changeLang', ['locale' => 'fr']) }}">Fr</a></li>
    </ul>
    <a class="btn btn-primary" href="{{ route('clients.index', ['locale' => session()->get('locale')]) }}"> Back</a>
        @if(session('status'))
        <div class="alert alert-success mb-1 mt-1">
            {{ session('status') }}
        </div>
        @endif
        <form action="{{ route('clients.store', ['locale' => session()->get('locale')]) }}" method="POST" enctype="multipart/form-data">
            @csrf
                    <div>
                        <strong>Name:</strong>
                        <input type="text" name="name" class="form-control">
                        @error('name')
                            <div>{{ $message }}</div>
                        @enderror
                    </div>
                    <div>
                        <strong>Email:</strong>
                        <input type="email" name="email" class="form-control">
                        @error('email')
                            <div>{{ $message }}</div>
                        @enderror
                    </div>
                    <input type="file" name="photo">
                <button type="submit">Submit</button>
        </form>
        {{ __('myapp.Hello') }}
</body>

</html>