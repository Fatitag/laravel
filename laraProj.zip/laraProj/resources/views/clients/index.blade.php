
    
    <a href="{{ route('clients.create') }}"> Create client</a>
    @if ($message = Session::get('success'))
        <p>{{ $message }}</p>
    @endif
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($clients as $client)
                <tr>
                    <td><img src="/storage/{{ $client->photo }}" alt=""></td>
                    <td>{{ $client->id }}</td>
                    <td>{{ $client->name }}</td>
                    <td>{{ $client->email }}</td>
                    <td>
                    <a class="btn btn-primary" href="{{ route('clients.edit', $client->id) }}">Edit</a>
                    <form action="{{ route('clients.destroy', $client->id) }}" method="Post">
                        @csrf
                        @method('DELETE')

                        @can('delete', App\Models\Client::class)
                            <button type="submit" class="btn btn-danger">Delete</button>
                        @endcan
                    </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $clients->links() }}

    <img src="storage/47TPY5Yivf1RzuroZ0WU9NGu2dVR22xzNqleeCCX.jpg" alt="">
