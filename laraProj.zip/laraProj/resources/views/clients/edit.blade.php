<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Company Form - Laravel 9 CRUD Tutorial</title>
</head>

<body>
    <div class="container mt-2">
    <a class="btn btn-primary" href="{{ route('clients.index') }}" enctype="multipart/form-data">
                        Back</a>
        @if(session('status'))
        <div>
            {{ session('status') }}
        </div>
        @endif
        <form action="{{ route('clients.update', $client->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            <div class="row">
                    <div>
                        <strong>Name:</strong>
                        <input type="text" name="name" value="{{ $client->name }}">
                        @error('name')
                        <div>{{ $message }}</div>
                        @enderror
                    </div>
                    <div>
                        <strong>Email:</strong>
                        <input type="email" name="email" value="{{ $client->email }}">
                        @error('email')
                        <div>{{ $message }}</div>
                        @enderror
                    </div>
                <button type="submit">Submit</button>
            </div>
        </form>
    </div>
</body>

</html>