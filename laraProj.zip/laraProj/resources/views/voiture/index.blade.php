<html>
    <body>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Marque</th>
                <th>Modèle</th>
            </tr>
            @foreach ($voitures as $voiture)
            <tr>
                <td>{{ $voiture->id }}</td>
                <td>{{ $voiture->marque }}</td>
                <td>{{ $voiture->modele }}</td>
            </tr>
            @endforeach
        </table>
    </body>
</html>