<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
        @foreach($errors->all() as $error)
            <li>{{ $error }}</li>
        @endforeach
    </ul>
    <form action="" method="post" enctype="multipart/form-data">
        <div>
            <label>Nom</label>
            <input type="text" name="nom" value="{{ old('nom') }}" />
            @error('nom')
                <div class="alert alert-danger">{{ $message }}</div>
            @enderror
        </div>
        <div>
            <label>Prénom</label>
            <input type="text" name="prenom" value="{{ old('prenom') }}" />
        </div>
        <div>
            <label>Email</label>
            <input type="text" name="email" value="{{ old('email') }}" />
        </div>
        <div>
            <label>Photo</label>
            <input type="file" name="photo" />
        </div>
        @csrf
        <input type="submit" value="Envoyer" />
    </form>
</body>
</html>