<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClientController;
use App\Http\Controllers\TestController;
use App\Http\Middleware\CheckRole;
use App\Http\Middleware\TestMiddleWare;
use App\Models\Client2;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');

Route::resource('clients', ClientController::class);

Route::get('/edit', [TestController::class, 'test2'])->middleware(CheckRole::class);

Route::any('/test/{id}', [TestController::class, 'test2'])->where('id', '[0-9]+');

Route::get('/{locale}/changeLang', [ClientController::class, 'changeLang'])->name('changeLang');

Route::get('/test3', [TestController::class, 'test3'])->middleware(TestMiddleWare::class);

require __DIR__.'/auth.php';
