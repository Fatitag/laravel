<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class Client2Factory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'nom' => $this->faker->lastName(),
            'prenom' => $this->faker->firstName(),
            'telephone' => $this->faker->phoneNumber(),
            'email' => $this->faker->email(),
            'adresse' => $this->faker->address(),
        ];
    }
}
