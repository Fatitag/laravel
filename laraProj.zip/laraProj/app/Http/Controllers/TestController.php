<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TestController extends Controller
{
    public function index(Request $request)
    {
        if ( $request->isMethod('post') )
        {
            $request->validate([
                'nom' => 'required|email',
            ]);

            echo $request->input('nom');
        }

        return view('test2');
    }

    public function form(Request $request)
    {
        if ( $request->isMethod('post') )
        {
            $r = $request->validate([
                'nom' => 'required',
                'email' => 'required|email',
                'photo' => 'image|max:50'
            ]);
        }

        return view('test.index');
    }

    public function test2($id)
    {
        echo $id;
        exit();
        return view('test2');
    }

    public function test3(Request $request)
    {
        echo $_SERVER['HTTP_USER_AGENT'];
    }
}
