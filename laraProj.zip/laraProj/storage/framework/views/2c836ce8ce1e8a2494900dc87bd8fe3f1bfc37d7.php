
    
    <a href="<?php echo e(route('clients.create')); ?>"> Create client</a>
    <?php if($message = Session::get('success')): ?>
        <p><?php echo e($message); ?></p>
    <?php endif; ?>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><img src="/storage/<?php echo e($client->photo); ?>" alt=""></td>
                    <td><?php echo e($client->id); ?></td>
                    <td><?php echo e($client->name); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td>
                    <a class="btn btn-primary" href="<?php echo e(route('clients.edit', $client->id)); ?>">Edit</a>
                    <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="Post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', App\Models\Client::class)): ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        <?php endif; ?>
                    </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($clients->links()); ?>


    <img src="storage/47TPY5Yivf1RzuroZ0WU9NGu2dVR22xzNqleeCCX.jpg" alt="">
<?php /**PATH D:\xampp\htdocs\laraProj\resources\views/clients/index.blade.php ENDPATH**/ ?>