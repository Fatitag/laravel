
<?php $__env->startSection('content'); ?>
    <p>Page produits 2</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
    <p>2</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MyLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/produits2.blade.php ENDPATH**/ ?>