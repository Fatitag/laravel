
<?php $__env->startSection('content'); ?>
    <h1>Page index</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.testLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/salle/index.blade.php ENDPATH**/ ?>