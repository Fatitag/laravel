<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Add Company Form - Laravel 9 CRUD</title>
</head>

<body>
    <ul>
        <li><a href="<?php echo e(route('changeLang', ['locale' => 'en'])); ?>">En</a></li>
        <li><a href="<?php echo e(route('changeLang', ['locale' => 'fr'])); ?>">Fr</a></li>
    </ul>
    <a class="btn btn-primary" href="<?php echo e(route('clients.index', ['locale' => session()->get('locale')])); ?>"> Back</a>
        <?php if(session('status')): ?>
        <div class="alert alert-success mb-1 mt-1">
            <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('clients.store', ['locale' => session()->get('locale')])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                    <div>
                        <strong>Name:</strong>
                        <input type="text" name="name" class="form-control">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <strong>Email:</strong>
                        <input type="email" name="email" class="form-control">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <input type="file" name="photo">
                <button type="submit">Submit</button>
        </form>
        <?php echo e(__('myapp.Hello')); ?>

</body>

</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/clients/create.blade.php ENDPATH**/ ?>