<html>
    <head>
        <style>
            .is-invalid {
                border: 1px red solid;
            }
        </style>
    </head>
    <body>
        <form action="" method="post" enctype="multipart/form-data">
            <?php if( $errors->any() ): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div>
                <label>Nom</label>
                <input type="text" name="nom" value="<?php echo e(old('nom')); ?>" class="<?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
            </div>
            <input type="file" name="photo" />
            <?php echo csrf_field(); ?>
            <input type="submit" value="Envoyer" />
        </form>
    </body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/test.blade.php ENDPATH**/ ?>