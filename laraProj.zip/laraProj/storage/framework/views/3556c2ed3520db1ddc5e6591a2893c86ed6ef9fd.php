<html>
    <body>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Marque</th>
                <th>Modèle</th>
            </tr>
            <?php $__currentLoopData = $voitures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voiture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($voiture->id); ?></td>
                <td><?php echo e($voiture->marque); ?></td>
                <td><?php echo e($voiture->modele); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/voiture/index.blade.php ENDPATH**/ ?>