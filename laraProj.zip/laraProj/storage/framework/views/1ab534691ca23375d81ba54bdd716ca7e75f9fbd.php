
<?php $__env->startSection('content'); ?>
    <p>Page produits</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('nav'); ?>
    <form action="" method="post" enctype="multipart/form-data">
        <?php if( $errors->any() ): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
       
        <div>
            <label>Name</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" />
        </div>
        <div>
            <label>Filière</label>
            <select name="fil">
                <option></option>
                <option value="tdi" @selected(old('fil') == 'tdi')>TDI</option>
                <option value="tri" @selected(old('fil') == 'tri')>TRI</option>
            </select>
        </div>
        <div>
            <label>Sexe</label>
            <input type="radio" name="sexe" value="h" />
            <input type="radio" name="sexe" value="f" />
        </div>
        <div>
            <label>Options</label>
            <input type="checkbox" name="option[]" value="1A" />
            <input type="checkbox" name="option[]" value="2A" />
        </div>
        <div>
            <label>Photo</label>
            <input type="file" name="photo" />
        </div>
        <?php echo csrf_field(); ?>
        <input type="submit" value="Envoyer" />
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.MyLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/produits.blade.php ENDPATH**/ ?>