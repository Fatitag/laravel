<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <header>
        <h1>Header</h1>
        <ul>
            <li><a href="<?php echo e(route('salles')); ?>">Index</a></li>
            <li><a href="<?php echo e(route('ajouter')); ?>">Ajouter</a></li>
        </ul>
    </header>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        <p>Copyright 2023</p>
    </footer>
</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/layouts/testLayout.blade.php ENDPATH**/ ?>