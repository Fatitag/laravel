<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <form action="" method="post" enctype="multipart/form-data">
        <div>
            <label>Nom</label>
            <input type="text" name="nom" value="<?php echo e(old('nom')); ?>" />
            <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label>Prénom</label>
            <input type="text" name="prenom" value="<?php echo e(old('prenom')); ?>" />
        </div>
        <div>
            <label>Email</label>
            <input type="text" name="email" value="<?php echo e(old('email')); ?>" />
        </div>
        <div>
            <label>Photo</label>
            <input type="file" name="photo" />
        </div>
        <?php echo csrf_field(); ?>
        <input type="submit" value="Envoyer" />
    </form>
</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/myForm.blade.php ENDPATH**/ ?>