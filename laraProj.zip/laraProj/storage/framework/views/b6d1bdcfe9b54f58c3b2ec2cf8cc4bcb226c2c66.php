<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(route('employes.create')); ?>">Ajouter</a>
    <table>
        <tr>
            <th>ID</th>
            <th>First name</th>
            <th>Last name</th>
            <th>Salary</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $employes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($employe->id); ?></td>
                <td><?php echo e($employe->firstName); ?></td>
                <td><?php echo e($employe->lastName); ?></td>
                <td><?php echo e($employe->salary); ?></td>
                <td>
                    <a href="<?php echo e(route('employes.show', ['employe' => $employe->id])); ?>">Afficher</a>
                    <a href="#">Modifier</a>
                    <form action="<?php echo e(route('employes.destroy', ['employe' => $employe->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="submit" value="Supprimer">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($employes->links()); ?>

</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/employe/index.blade.php ENDPATH**/ ?>