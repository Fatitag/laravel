<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <p><strong>First name: </strong> <?php echo e($employe->firstName); ?></p>
    <p><strong>Last name: </strong> <?php echo e($employe->lastName); ?></p>
    <p><strong>Salary: </strong> <?php echo e($employe->salary); ?></p>
    <p><strong>Birth date: </strong> <?php echo e($employe->birthDate); ?></p>
</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/employe/show.blade.php ENDPATH**/ ?>