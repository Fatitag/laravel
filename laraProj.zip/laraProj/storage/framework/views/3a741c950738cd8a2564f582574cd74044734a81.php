<html>
    <head>
        <link rel="stylesheet" href="/css/style.css" />
    </head>
    <body>
        <h1>Bonjour!</h1>
        <?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/layouts/MyLayout.blade.php ENDPATH**/ ?>