<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <a href="<?php echo e(route('produits.create')); ?>">Ajouter</a>
    <table>
        <tr>
            <th>ID</th>
            <th>Libellé</th>
            <th>Prix</th>
            <th>Actions</th>
        </tr>
        <?php $__currentLoopData = $produits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($produit->id); ?></td>
                <td><?php echo e($produit->libelle); ?></td>
                <td><?php echo e($produit->prix); ?></td>
                <th>
                    <a href="<?php echo e(route('produits.show', ['produit' => $produit])); ?>">Afficher</a>
                    <a href="<?php echo e(route('produits.edit', ['produit' => $produit])); ?>">Modifier</a>
                    <form action="<?php echo e(route('produits.destroy', ['produit' => $produit])); ?>" method="post">
                        <input type="submit" value="Supprimer">
                        <?php echo csrf_field(); ?>
                        
                    </form>
                </th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($produits->links()); ?>

</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/produit/index.blade.php ENDPATH**/ ?>