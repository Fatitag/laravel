<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <form action="" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="">Nom</label>
        <input type="text" name="nom"><br />
        <label for="">Email</label>
        <input type="text" name="email"><br />
        <label for="">Groupe</label>
        201<input type="radio" value="201" name="groupe">
        202<input type="radio" value="202" name="groupe">
        203<input type="radio" value="203" name="groupe"><br />
        <label for="">Modules</label>
        m1<input type="checkbox" value="m1" name="module[]">
        m2<input type="checkbox" value="m2" name="module[]">
        m3<input type="checkbox" value="m3" name="module[]"><br />
        <input type="file" name="photo">
        <input type="submit" value="ok">
    </form>
</body>
</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/test/index.blade.php ENDPATH**/ ?>