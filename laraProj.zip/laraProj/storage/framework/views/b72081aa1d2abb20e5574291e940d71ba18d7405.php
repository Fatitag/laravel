<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Edit Company Form - Laravel 9 CRUD Tutorial</title>
</head>

<body>
    <div class="container mt-2">
    <a class="btn btn-primary" href="<?php echo e(route('clients.index')); ?>" enctype="multipart/form-data">
                        Back</a>
                        <p><?php echo e($client->name); ?></p>
                        <p><?php echo e($client->email); ?></p>

    <?php $__currentLoopData = $client->commandes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $commande): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($commande->id); ?>: <?php echo e($commande->dateCom); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>

</html><?php /**PATH D:\xampp\htdocs\laraProj\resources\views/clients/show.blade.php ENDPATH**/ ?>